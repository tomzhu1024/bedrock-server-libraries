LD_PRELOAD= ./ld-linux-x86-64.so.2 --inhibit-cache --library-path . ./bedrock_server
